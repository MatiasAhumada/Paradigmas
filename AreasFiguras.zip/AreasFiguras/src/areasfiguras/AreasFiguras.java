/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package areasfiguras;

import Modelo.Circulo;
import Modelo.Cuadrado;
import Modelo.Figuras;
import Modelo.Triangulo;

/**
 *
 * @author bonaparte
 */
public class AreasFiguras {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Figuras figuras = new Figuras();
        Cuadrado cuadrado1 = new Cuadrado(10);
        figuras.agregarFigura(cuadrado1);
        Cuadrado cuadrado2 = new Cuadrado();
        cuadrado2.setLado(30);
        figuras.agregarFigura(cuadrado2);
        Circulo circulo1 = new Circulo((float) 2.4);
        figuras.agregarFigura(circulo1);
        Triangulo triangulo1 = new Triangulo(4, 5);
        figuras.agregarFigura(triangulo1);

        figuras.calcularAreas();
        figuras.mostrar();
    }
    
}
