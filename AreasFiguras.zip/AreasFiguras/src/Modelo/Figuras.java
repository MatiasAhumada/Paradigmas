/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

import java.util.ArrayList;

/**
 *
 * @author bonaparte
 */
public class Figuras {
    private ArrayList<Figura> figuras = new ArrayList<>();

    public Figuras(){}
    
    public ArrayList<Figura> getFiguras() {
        return figuras;
    }

    public void setFiguras(ArrayList<Figura> figuras) {
        this.figuras = figuras;
    }
    
    public void agregarFigura(Figura figura){
        figuras.add(figura);
    }
    
    public void calcularAreas(){
        for(Figura figura : figuras){
            figura.calcularArea();
        }
    }
    public void mostrar(){
      for(Figura figura : figuras){
         System.out.println(figura);
      }
    }
}
