/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author bonaparte
 */
public class Cuadrado extends Figura {
    private float lado;
    
    public Cuadrado(){}
    
    public Cuadrado(float lado){
        this.lado = lado;
    }

    public float getLado() {
        return lado;
    }

    public void setLado(float lado) {
        this.lado = lado;
    }
    
    @Override
    public void calcularArea(){
        setArea(lado * lado);
    }

    @Override
    public String toString() {
        return "Cuadrado{" + " lado = " + lado + " Area = " + super.getArea() + " }";
    }
    
}
