/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author bonaparte
 */
public class Circulo extends Figura {
    private float radio;
    
    public Circulo(){}
    
    public Circulo(float radio){
        this.radio = radio;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }
    
    @Override
    public void calcularArea(){
        setArea((float) 3.14 * (radio * radio));
    }

    @Override
    public String toString() {
        return "Circulo{" + " radio = " + radio + " Area = " + super.getArea() + " }";
    }
    
}
