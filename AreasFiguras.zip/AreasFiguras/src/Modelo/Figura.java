/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author bonaparte
 */
public abstract class Figura {
    private float area;
    
    public void setArea(float area){
        this.area = area;
    }
    
    public float getArea(){
        return area;
    }
    
    public abstract void calcularArea();
    
}
